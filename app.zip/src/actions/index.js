 
export const createEvent = event => {
  return (dispatch, { getFirestore }) => {
    const firestore = getFirestore();
    firestore
      .collection("Events")
      .add({
        ...event
      })
      .then(() => dispatch({ type: "SUCCESS", payload: event }))
      .catch({ type: "ERROR" });
  };
};
