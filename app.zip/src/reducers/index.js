import {combineReducers} from 'redux'
import eventsReducers from './eventsReducers'
import firebaseReducer from 'react-redux-firebase'
import firestoreReducer from 'redux-firestore'
export default combineReducers({
    events: eventsReducers,
    firestore: firestoreReducer,
    firebase: firebaseReducer
})