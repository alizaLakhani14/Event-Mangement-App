let events = [];

export default (state = events, action) => {
  switch (action.type) {
    case "SUCCESS":
      console.log("Successfully created event.")
      return state;
      case "ERROR":
        console.log("Error occurred")
        return state;

    default:
      return state;
  }
};
