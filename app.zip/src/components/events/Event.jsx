// import React from 'react';
// import { Card } from 'antd';
// import './Event.css';

// const Event = (props) => {
// 	return (
// 		<Card title={props.title} bordered={false} className='EventCard'>
// 			{props.description}
// 		</Card>
// 	);
// };

// export default Event;



